Client setup:
1. cd client
2. npm install
3. npm start
