PROFESSIONAL_CHAT_APP - Fullstack personalized chat (React + Express + MongoDB + Socket.IO)

Local setup:
  1. server: cd server; cp .env.example .env; fill values; npm install; npm run dev
  2. client: cd client; cp .env.example .env; npm install; npm start

Deployment:
  - Backend: Render / Railway / Heroku (set env vars: MONGODB_URI, JWT_SECRET, CLIENT_URL)
  - Frontend: Vercel (set env var REACT_APP_API_URL to backend URL)
