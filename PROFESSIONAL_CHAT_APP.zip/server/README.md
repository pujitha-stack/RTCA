Server setup:
1. cd server
2. cp .env.example .env and fill values
3. npm install
4. npm run dev
