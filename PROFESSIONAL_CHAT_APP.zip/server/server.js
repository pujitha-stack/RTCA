require('dotenv').config();
const express = require('express');
const http = require('http');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const socketio = require('socket.io');
const User = require('./models/User');
const Chat = require('./models/Chat');
const Message = require('./models/Message');

const app = express();
const server = http.createServer(app);
const io = new socketio.Server(server, {
  cors: { origin: process.env.CLIENT_URL || 'http://localhost:3000', credentials: true }
});

app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:3000', credentials: true }));
app.use(express.json());
app.use(cookieParser());

const JWT_SECRET = process.env.JWT_SECRET || 'change_this_secret';
const PORT = process.env.PORT || 4000;

mongoose.connect(process.env.MONGODB_URI, {})
  .then(()=> console.log('MongoDB connected'))
  .catch((err) => { console.error('MongoDB connection error:', err); process.exit(1) });

// Helpers
function authMiddleware(req, res, next) {
  try {
    const token = req.cookies?.token || (req.headers.authorization && req.headers.authorization.split(' ')[1]);
    if (!token) return res.status(401).json({ error: 'Unauthorized' });
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
}

// Auth routes
app.post('/api/auth/signup', async (req, res) => {
  try {
    const { email, password, fullName } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Missing fields' });
    const exists = await User.findOne({ email: email.toLowerCase() });
    if (exists) return res.status(400).json({ error: 'User already exists' });
    const user = await User.create({ email: email.toLowerCase(), password, fullName });
    const token = jwt.sign({ id: user._id.toString(), email: user.email, fullName: user.fullName }, JWT_SECRET, { expiresIn: '7d' });
    res.cookie('token', token, { httpOnly: true, maxAge: 7*24*60*60*1000, sameSite: 'lax' });
    res.json({ user: { id: user._id.toString(), email: user.email, fullName: user.fullName } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Missing fields' });
    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });
    const valid = await user.comparePassword(password);
    if (!valid) return res.status(400).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ id: user._id.toString(), email: user.email, fullName: user.fullName }, JWT_SECRET, { expiresIn: '7d' });
    res.cookie('token', token, { httpOnly: true, maxAge: 7*24*60*60*1000, sameSite: 'lax' });
    res.json({ user: { id: user._id.toString(), email: user.email, fullName: user.fullName } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/auth/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ success: true });
});

app.get('/api/auth/session', async (req, res) => {
  try {
    const token = req.cookies?.token || (req.headers.authorization && req.headers.authorization.split(' ')[1]);
    if (!token) return res.json({ user: null });
    const decoded = jwt.verify(token, JWT_SECRET);
    return res.json({ user: decoded });
  } catch (err) {
    return res.json({ user: null });
  }
});

// Chats & messages
app.get('/api/chats', authMiddleware, async (req, res) => {
  try {
    const chats = await Chat.find({ participants: req.user.id }).sort({ createdAt: -1 });
    res.json({ chats });
  } catch (err) { res.status(500).json({ error: 'Internal server error' }); }
});

app.post('/api/chats', authMiddleware, async (req, res) => {
  try {
    const { title, participantIds } = req.body;
    const chat = await Chat.create({ title: title || null, participants: participantIds || [req.user.id] });
    res.json({ chat });
  } catch (err) { res.status(500).json({ error: 'Internal server error' }); }
});

app.get('/api/messages', authMiddleware, async (req, res) => {
  try {
    const { chatId } = req.query;
    if (!chatId) return res.status(400).json({ error: 'Missing chatId' });
    const messages = await Message.find({ chatId }).sort({ createdAt: 1 });
    res.json({ messages });
  } catch (err) { res.status(500).json({ error: 'Internal server error' }); }
});

// Socket.IO auth via cookie/token
io.use((socket, next) => {
  try {
    const token = socket.handshake.auth?.token || socket.handshake.headers?.cookie?.split('token=')[1] || socket.handshake.query?.token;
    if (!token) return next(new Error('Authentication error'));
    const decoded = jwt.verify(token, JWT_SECRET);
    socket.user = decoded;
    return next();
  } catch (err) {
    return next(new Error('Authentication error'));
  }
});

io.on('connection', (socket) => {
  console.log('socket connected', socket.user?.email);

  // join personal room and any provided room id
  const personal = `user:${socket.user.id}`;
  socket.join(personal);

  socket.on('join-room', (roomId) => { socket.join(roomId); });
  socket.on('leave-room', (roomId) => { socket.leave(roomId); });

  socket.on('send-message', async (payload) => {
    try {
      const message = await Message.create({ chatId: payload.chatId || 'global', senderId: socket.user.id, senderName: socket.user.fullName || socket.user.email, content: payload.content });
      io.to(payload.chatId || 'global').emit('new-message', message);
    } catch (err) { console.error(err); }
  });

  socket.on('disconnect', () => { console.log('socket disconnected'); });
});

server.listen(PORT, () => { console.log('Server listening on port', PORT); });
