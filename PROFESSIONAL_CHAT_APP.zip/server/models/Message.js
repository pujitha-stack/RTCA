const mongoose = require('mongoose');
const { Schema } = mongoose;

const MessageSchema = new Schema({
  chatId: { type: String, default: 'global' },
  senderId: { type: String },
  senderName: { type: String },
  content: { type: String },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Message', MessageSchema);
