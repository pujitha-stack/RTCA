-- Insert sample admin user (you'll need to sign up first, then update the role)
-- UPDATE profiles SET role = 'admin' WHERE email = 'admin@example.com';

-- Insert sample users (these will be created when users sign up)
-- This is just for reference - actual users are created through the signup process

-- Sample data will be created through the application interface
-- Users can sign up and create chats through the UI
